package Avaliação;

public class Medico extends Profissional{
    private String crm;
}
