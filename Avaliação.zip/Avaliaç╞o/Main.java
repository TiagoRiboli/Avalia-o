package Avaliação;

public class Main {
    public static void main(String[] args) {
        Engenheiro engenheiro1 = new Engenheiro();
        engenheiro1.setCpf("112.912.279-46");
        engenheiro1.setNome("Tiago Riboli");
        engenheiro1.setSalarioBruto(1000.00f);
        engenheiro1.mostrarDados();
        System.out.println("Salário liquido: "+ engenheiro1.calcularSalarioLiquido(0.9f, 600.00f));
        System.out.println("\n");

        Professor professor1 = new Professor();
        professor1.setCpf("112.912.279-46");
        professor1.setNome("Tiago Riboli");
        professor1.setHorasTrabalhadas(10);
        professor1.setSalarioBruto(10.00f);
        professor1.mostrarDados();
        System.out.println("Salário liquido: "+ professor1.calcularSalarioLiquido(0.9f));
    }
}
