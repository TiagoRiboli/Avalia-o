package Avaliação;

public class Professor extends Profissional{

    private int horasTrabalhadas;

    public int getHorasTrabalhadas() {
        return horasTrabalhadas;
    }

    public void setHorasTrabalhadas(int horasTrabalhadas) {
        this.horasTrabalhadas = horasTrabalhadas;
    }

    @Override
    public float calcularSalarioLiquido(float desconto, float bonus) {
        return ((getSalarioBruto() * horasTrabalhadas) * desconto) + bonus;
    }

    public float calcularSalarioLiquido(float desconto) {
        return ((getSalarioBruto() * horasTrabalhadas) * desconto);
    }
}
