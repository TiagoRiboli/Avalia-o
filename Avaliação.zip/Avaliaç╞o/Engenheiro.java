package Avaliação;

public class Engenheiro extends Profissional {
    private String crea;


}
