package Avaliação;

public class Profissional {
    private String cpf;
    private String nome;
    private float salarioBruto;

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getSalarioBruto() {
        return salarioBruto;
    }

    public void setSalarioBruto(float salarioBruto) {
        this.salarioBruto = salarioBruto;
    }

    public float calcularSalarioLiquido(float desconto, float bonus){
        return (salarioBruto * desconto) + bonus;
    }
    public void mostrarDados(){
        System.out.println("Nome: "+ this.nome);
        System.out.println("CPF: "+ this.cpf);
    }
}
